

/* Bx Slider */ 

    $(document).ready(function(){
      $('.slider_area_image').bxSlider();
        $('#main_menu').meanmenu({
            meanMenuContainer: '#mobile_menu', 
            meanScreenWidth: 991,
        });
    });
